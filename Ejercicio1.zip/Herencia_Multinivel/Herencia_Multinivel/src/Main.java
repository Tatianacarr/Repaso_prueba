import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        BecadoExcelencia becado = new BecadoExcelencia();

        System.out.println("=== ESTUDIANTE BECADO ===");
        System.out.print("Código: ");
        becado.setCodigo(sc.nextLine());

        System.out.print("Nombre: ");
        becado.setNombre(sc.nextLine());

        System.out.print("Promedio: ");
        becado.setPromedio(sc.nextDouble());

        System.out.print("Valor matrícula: ");
        becado.setValorMatricula(sc.nextDouble());

        System.out.print("Porcentaje beca: ");
        becado.setPorcentajeBeca(sc.nextDouble());

        System.out.print("Bono excelencia: ");
        becado.setBonoExcelencia(sc.nextDouble());

        // OBJETO 2 (RegularConRecargo)
        RegularConRecargo regular = new RegularConRecargo();

        sc.nextLine(); // limpiar buffer

        System.out.println("\n=== ESTUDIANTE REGULAR ===");
        System.out.print("Código: ");
        regular.setCodigo(sc.nextLine());

        System.out.print("Nombre: ");
        regular.setNombre(sc.nextLine());

        System.out.print("Promedio: ");
        regular.setPromedio(sc.nextDouble());

        System.out.print("Valor matrícula: ");
        regular.setValorMatricula(sc.nextDouble());

        System.out.print("Número de materias: ");
        regular.setNumeroMaterias(sc.nextInt());

        System.out.print("Recargo pendiente: ");
        regular.setRecargoPendiente(sc.nextDouble());
        Estudiante e1 = becado;
        Estudiante e2 = regular;

        System.out.println("\n--- RESULTADOS ---");

        e1.mostrarDatos();
        System.out.println("Pago final: $" + e1.calcularPagoFinal());

        System.out.println();

        e2.mostrarDatos();
        System.out.println("Pago final: $" + e2.calcularPagoFinal());
    }
}